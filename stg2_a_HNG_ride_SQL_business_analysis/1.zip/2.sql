SELECT COUNT(DISTINCT r.rider_id) AS retained_riders
FROM completed_rides r
JOIN rider ri ON r.rider_id = ri.rider_id
WHERE EXTRACT(YEAR FROM ri.signup_date) = 2021
  AND EXTRACT(YEAR FROM r.event_time) = 2024;


