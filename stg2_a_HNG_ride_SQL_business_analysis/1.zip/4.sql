--- Top 5 drivers by consistency
WITH driver_months AS (
    SELECT driver_id,
           DATE_TRUNC('month', event_time) AS month
    FROM completed_rides
    GROUP BY driver_id, month
)
SELECT d.driver_id, d.name,
       COUNT(r.ride_id)::DECIMAL / COUNT(DISTINCT DATE_TRUNC('month', r.event_time)) AS avg_rides_per_month
FROM completed_rides r
JOIN drivers d ON r.driver_id = d.driver_id
GROUP BY d.driver_id, d.name
ORDER BY avg_rides_per_month DESC
LIMIT 5;
