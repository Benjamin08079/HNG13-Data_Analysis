SELECT r.ride_id, r.distance_km, d.name AS driver_name, ri.name AS rider_name,
       r.pickup_city, r.dropoff_city, r.payment_method
FROM completed_rides r
JOIN drivers d ON r.driver_id = d.driver_id
JOIN rider ri ON r.rider_id = ri.rider_id
ORDER BY r.distance_km DESC
LIMIT 10;
