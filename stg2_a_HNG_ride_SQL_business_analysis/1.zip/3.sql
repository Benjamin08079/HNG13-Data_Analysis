---Compare quarterly revenue between 2021, 2022, 2023, and 2024. Which quarter had the biggest YoY growth?


SELECT EXTRACT(YEAR FROM event_time) AS year,
       EXTRACT(QUARTER FROM event_time) AS quarter,
       SUM(fare) AS total_revenue
FROM completed_rides
GROUP BY year, quarter
ORDER BY year, quarter;
