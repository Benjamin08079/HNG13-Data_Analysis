---Cancellation rate per city
SELECT pickup_city,
       COUNT(*) FILTER (WHERE status = 'Cancelled')::DECIMAL / COUNT(*) * 100 AS cancellation_rate
FROM rides
GROUP BY pickup_city
ORDER BY cancellation_rate DESC;
