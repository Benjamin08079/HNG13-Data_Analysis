--Identify riders who have taken more than 10 rides but never paid with cash.

SELECT r.rider_id, ri.name, COUNT(*) AS total_rides
FROM completed_rides r
JOIN rider ri ON r.rider_id = ri.rider_id
WHERE r.payment_method != 'Cash'
GROUP BY r.rider_id, ri.name
HAVING COUNT(*) > 10;
