--Top 3 drivers per city by revenue.

SELECT *
FROM (
    SELECT driver_id, pickup_city, SUM(fare) AS total_revenue,
           ROW_NUMBER() OVER (PARTITION BY pickup_city ORDER BY SUM(fare) DESC) AS rn
    FROM completed_rides
    GROUP BY driver_id, pickup_city
) t
WHERE rn <= 3
ORDER BY pickup_city, total_revenue DESC;
