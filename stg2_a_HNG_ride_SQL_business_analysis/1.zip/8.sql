--The top 10 drivers who are qualified to receive bonuses
WITH driver_stats AS (
    SELECT 
           r.driver_id,
           COUNT(*) AS total_rides,
           AVG(d.rating) AS avg_rating,
           COUNT(*) FILTER (WHERE r.status = 'Cancelled')::DECIMAL / COUNT(*) * 100 AS cancellation_rate
    FROM completed_rides r
    JOIN drivers d ON r.driver_id = d.driver_id
    GROUP BY r.driver_id
)
SELECT 
       ds.driver_id, 
       d.name, 
       ds.total_rides, 
       ds.avg_rating, 
       ds.cancellation_rate
FROM driver_stats ds
JOIN drivers d ON ds.driver_id = d.driver_id
WHERE ds.total_rides >= 30
  AND ds.avg_rating >= 4.5
  AND ds.cancellation_rate < 5
ORDER BY ds.total_rides DESC;


